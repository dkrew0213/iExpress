Windows Todo
============

This is a sample application that showcases the Parse Windows SDK.  It contains a Visual Studio C# Solution that shows how easy it is to get started creating and storing data using Parse as your backend.

How to Run
----------

1. Clone the repository and open the Visual Studio solution.
2. Ensure that automatic library download from NuGet is enabled in Visual Studio by going to Tools-->Options-->Package Manager and checking "Allow NuGet to download missing packages during build"
3. Add your Parse application id and windows key in `App.xaml.cs`
4. Build and run.
